
import os
import subprocess
import tkinter as tk
from tkinter import messagebox, filedialog
from time import sleep
import threading
import signal
import sys

DEFAULT_GAME_PATH = r"E:\steam\steamapps\common\Don't Starve Together Dedicated Server\bin64"
DEFAULT_CLUSTER_NAME = "MyDediServer"

class DSTLauncherApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Don't Starve Together 启动器（弹窗控制台 + 可关闭）")
        self.geometry("550x420")
        self.resizable(False, False)

        self.game_path = tk.StringVar(value=DEFAULT_GAME_PATH)
        self.cluster_name = tk.StringVar(value=DEFAULT_CLUSTER_NAME)

        self.master_proc = None
        self.caves_proc = None

        self.create_widgets()

    def create_widgets(self):
        tk.Label(self, text="DST Dedicated Server 路径:").pack(anchor='w', padx=10, pady=5)
        tk.Entry(self, textvariable=self.game_path, width=60).pack(padx=10)
        tk.Button(self, text="浏览", command=self.browse_game_path).pack(pady=3)

        tk.Label(self, text="Cluster 名称（保存世界配置的文件夹）:").pack(anchor='w', padx=10, pady=5)
        tk.Entry(self, textvariable=self.cluster_name, width=40).pack(padx=10)

        btn_frame = tk.Frame(self)
        btn_frame.pack(pady=10)
        tk.Button(btn_frame, text="启动 Master + Caves", command=self.launch_servers, bg="#4CAF50", fg="white", width=22).grid(row=0, column=0, padx=10)
        tk.Button(btn_frame, text="优雅关闭服务器", command=self.graceful_shutdown, bg="#F44336", fg="white", width=22).grid(row=0, column=1, padx=10)

        self.status_text = tk.Text(self, height=12, width=65)
        self.status_text.pack(padx=10, pady=5)
        self.status_text.insert(tk.END, "准备就绪...
")
        self.status_text.configure(state='disabled')

    def browse_game_path(self):
        selected_dir = filedialog.askdirectory()
        if selected_dir:
            self.game_path.set(selected_dir)

    def append_status(self, message):
        self.status_text.configure(state='normal')
        self.status_text.insert(tk.END, message + "\n")
        self.status_text.see(tk.END)
        self.status_text.configure(state='disabled')

    def launch_servers(self):
        game_path = self.game_path.get()
        cluster = self.cluster_name.get()
        cluster_path = os.path.expanduser(f"~/Documents/Klei/DoNotStarveTogether/{cluster}")
        exe = os.path.join(game_path, "dontstarve_dedicated_server_nullrenderer_x64.exe")

        if not os.path.isfile(exe):
            messagebox.showerror("错误", f"找不到执行文件: {exe}")
            return
        if not os.path.isdir(cluster_path):
            messagebox.showerror("错误", f"找不到 cluster 路径: {cluster_path}")
            return

        self.append_status("✅ 正在启动 Master...")
        threading.Thread(target=self.run_server, args=(exe, cluster, "Master", "master_proc")).start()
        sleep(2)
        self.append_status("✅ 正在启动 Caves...")
        threading.Thread(target=self.run_server, args=(exe, cluster, "Caves", "caves_proc")).start()

    def run_server(self, exe, cluster, shard, attr_name):
        proc = subprocess.Popen([
            exe,
            "-console",
            "-cluster", cluster,
            "-shard", shard
        ], cwd=os.path.dirname(exe), creationflags=subprocess.CREATE_NEW_CONSOLE)
        setattr(self, attr_name, proc)
        self.append_status(f"🎉 {shard} 已启动（窗口已弹出）")

    def graceful_shutdown(self):
        shutdown_count = 0
        for proc in [self.master_proc, self.caves_proc]:
            if proc and proc.poll() is None:
                try:
                    proc.send_signal(signal.CTRL_BREAK_EVENT)
                    shutdown_count += 1
                    self.append_status(f"🟥 已向 PID {proc.pid} 发送 Ctrl+C")
                except Exception as e:
                    self.append_status(f"⚠️ 无法发送 Ctrl+C: {e}")
        if shutdown_count == 0:
            self.append_status("ℹ️ 没有需要关闭的服务器进程")

if __name__ == "__main__":
    if sys.platform != "win32":
        print("此脚本仅适用于 Windows")
        exit(1)
    app = DSTLauncherApp()
    app.mainloop()
